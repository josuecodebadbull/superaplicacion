<?php

session_start();
if (isset($_SESSION["user"])) {
  header("location:index.php");
}
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Login</title>
    <link rel="stylesheet" href="bootstrap/css/main.css" media="screen" title="no title" charset="utf-8">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" media="screen" title="no title" charset="utf-8">
    <meta name="viewport" content="width=device-width, initial scale=1">
    <script src="js/jquery-1.12.3.min.js" charset="utf-8"></script>
    <script src="bootstrap/js/bootstrap.min.js" charset="utf-8"></script>
    <script src="js/backstretch.min.js"></script>
  </head>
  <body>
    <div class="container">
      <div id="homespace" class="row">
        <div class="col-md-6">
            <img src="bootstrap/img/logo3.png" class="img-responsive" width="80px" height="80px">
        </div>
        <div class="col-md-6 text-right">
            <h3><a id='cuentanueva2' class="label label-info">Crear cuenta</a></h3>
        </div>
        <div id="menuspace" class="col-md-12">
            <div id="panellogin" class="panel1">
            <h1>SUPER APLICACIÓN</h1>
            <p>No somos la comunidad de gifs más grande, pero si somos la más cool.</p>
            <form method="post">
              <div class="form-group">
                  <input type="text" name="user" id="user" class="form-control" required="true" placeholder="usuario">
                  <input type="password" name="pass" id="pass" class="form-control" placeholder="contraseña">
                </div>
                <input type="button" name="login" id="login" value="ENVIAR" class="btn btn-md btn-block btn-info">
            <span id="result">
            <div class='alert alert-dismissible alert-danger'><button type='button' class='close' data-dismiss='alert'>&times;</button><strong>¡Error!</strong> las credenciales son incorrectas. <a id='cuentanueva'>Crear cuenta</a></div>    
            </span>
            </form>
            </div>
            
            <div id="panelnueva" class="panel1">
            <h1>ÚNETE A NOSOTROS</h1>
            <p id="instrucciones">Necesitamos un par de datos para que seas parte de nuestra comunidad</p>
            <form  method="post">
              <div class="form-group">
                  <input type="text" name="user2" id="user2" class="form-control" required="true" placeholder="usuario">
                  <input type="mail" name="correo2" id="correo2" class="form-control" required="true" placeholder="correo">
                  <input type="password" name="pass2" id="pass2" class="form-control" placeholder="contraseña">
                </div>
                <input type="button" name="login2" id="login2" value="UNIRSE" class="btn btn-md btn-block btn-info">
            <span id="result">
            <div class='alert alert-dismissible alert-danger'><button type='button' class='close' data-dismiss='alert'>&times;</button><strong>¡Error!</strong> las credenciales son incorrectas. <a id='cuentanueva'>Crear cuenta</a></div>    
            </span>
            </form>
            </div>
            
        </div>
        <div id="piehome" class="col-md-12 text-right">
            <p>CONDICIONES Copyright © [2016] [Diseños Code Bad Bull]</p>     
        </div>
      </div>
    </div>
  </body>
</html>
<script>


  $(document).ready(function() {
      
    $("#homespace").backstretch("bootstrap/img/back.gif");
    //ACCEDER A LA APP
    $('#login').click(function(){
      var user = $('#user').val();
      var pass = $('#pass').val();
      if($.trim(user).length > 0 && $.trim(pass).length > 0){
        $.ajax({
          url:"logueame.php",
          method:"POST",
          data:{user:user, pass:pass},
          cache:"false",
          beforeSend:function() {
            $('#login').val("Conectando...");
          },
          success:function(data) {
            $('#login').val("Login");
            if (data=="1") {
              $(location).attr('href','index.php');
            } else {
              //$(location).attr('href','logueame.php');
              $("#result").fadeIn();
            }
          }
        });
      };
    });
    var formData = new FormData(); 
    //JOIN TO APP
    $('#login2').click(function(){
      var user = $('#user2').val();
      var pass = $('#pass2').val();
      var mail = $('#correo2').val();
      if($.trim(mail).length > 0 && $.trim(user).length > 0 && $.trim(pass).length > 0){
        formData.append('user', user);
      formData.append('pass', pass);
      formData.append('mail', mail);
        $.ajax({
               url : 'unirme.php',
               type : 'POST',
               data : formData,
               processData: false,   
               contentType: false,   
               dataType: 'json',
               success : function(data) {
                if( data.error == '1'){
                   $("#instrucciones").text("UPS! Ya te ganaron ese nombre de usuario, ¡escoge otro!");
                }else{
                 $(location).attr('href','index.php'); 
                }  
               }
        }); 
      };
    });  
    
      
    $("#cuentanueva").click(function(){
        $("#homespace").backstretch("bootstrap/img/lluvia.gif");
        $("#panellogin").fadeOut("slow", function(){
            $("#panelnueva").fadeIn("slow");
        });
    });
      
    $("#cuentanueva2").click(function(){
        $("#homespace").backstretch("bootstrap/img/lluvia.gif");
        $("#panellogin").fadeOut("slow", function(){
            $("#panelnueva").fadeIn("slow");
        });
    });  
      
      
  });
</script>
