<?php

session_start();
$connect = mysqli_connect("localhost","josuecasa","josue2804","superaplicacion");
if(isset($_POST["user"]) && isset($_POST["pass"])){
  $user = mysqli_real_escape_string($connect, $_POST["user"]);
  $pass = mysqli_real_escape_string($connect, $_POST["pass"]);
  //echo $user;
  $sql = "SELECT user, id FROM usuario WHERE user='$user' AND pass='$pass'";
  //echo $sql;
  $result = mysqli_query($connect, $sql);
  $num_row = mysqli_num_rows($result);
  if ($num_row == "1") {
    $data = mysqli_fetch_array($result);
    $_SESSION["user"] = $data["user"];
    $_SESSION["id"] = $data["id"];
    echo "1";
  } else {
    echo "error no hay datos";
  }
} else {
  echo "error";
}

?>
