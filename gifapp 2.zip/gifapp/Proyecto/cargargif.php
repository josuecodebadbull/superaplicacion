<?php
session_start();
$connect = mysqli_connect("localhost","josuecasa","josue2804","superaplicacion");
$sql = "SELECT * FROM tabla_gif WHERE user='".$_SESSION["user"]."' AND pass='".$_SESSION["id"]."'";
  //echo $sql;
  $result = mysqli_query($connect, $sql);
  $num_row = mysqli_num_rows($result);
  echo $sql;
  
  if ($num_row == "1") {
   
  } else {
   
}

?>