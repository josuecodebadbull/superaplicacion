<?php
session_start();
$connect = mysqli_connect("localhost","josuecasa","josue2804","superaplicacion");
if(isset($_POST["user"]) && isset($_POST["pass"]) && isset($_POST["mail"])){
  $user = mysqli_real_escape_string($connect, $_POST["user"]);
  $pass = mysqli_real_escape_string($connect, $_POST["pass"]);
  $mail = mysqli_real_escape_string($connect, $_POST["mail"]);
  //Verificar si existe usuario con el mismo usuario_nombre
  $sql = "SELECT `id`, `user`, `email` FROM `usuario` WHERE user='".$user."'";
  $result = mysqli_query($connect, $sql);
  $num_row = mysqli_num_rows($result);
  if ($num_row > 0) {
    echo json_encode(array('error'=>'1'));
  } else {
    $sqlinsert = "INSERT INTO `usuario`(`user`, `pass`,`email` ) VALUES ('".$user."','".$pass."','".$mail."')";
    $insert = mysqli_query($connect, $sqlinsert);
    $_SESSION["user"] = $user;
    $sqlbuscarid = "SELECT user, id FROM usuario WHERE user='$user' AND pass='$pass'";
      $resultid = mysqli_query($connect, $sqlbuscarid);
      $num_rowid = mysqli_num_rows($resultid);
      if ($num_rowid == "1") {
        $data = mysqli_fetch_array($resultid);
        $_SESSION["id"] = $data["id"];
      }
    echo json_encode(array('error'=>'ok'));
    
  }
} 
?>
