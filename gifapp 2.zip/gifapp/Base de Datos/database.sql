-- phpMyAdmin SQL Dump
-- version 4.4.10
-- http://www.phpmyadmin.net
--
-- Servidor: localhost:8889
-- Tiempo de generación: 25-10-2016 a las 05:34:33
-- Versión del servidor: 5.5.42
-- Versión de PHP: 7.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Base de datos: `superaplicacion`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tabla_gif`
--

CREATE TABLE `tabla_gif` (
  `gif_id` smallint(6) NOT NULL,
  `gif_url` varchar(200) COLLATE utf8_bin NOT NULL,
  `gif_estatus` varchar(20) COLLATE utf8_bin NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `gif_fecha` date NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `tabla_gif`
--

INSERT INTO `tabla_gif` (`gif_id`, `gif_url`, `gif_estatus`, `usuario_id`, `gif_fecha`) VALUES
(57, 'uploads/josue2131/jesus.gif', 'S/N', 0, '0000-00-00'),
(58, 'uploads/josue2131/homero high.gif', 'S/N', 0, '0000-00-00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tabla_perfil`
--

CREATE TABLE `tabla_perfil` (
  `perfil_url` varchar(200) COLLATE utf8_bin NOT NULL,
  `usuario_id` varchar(100) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `id` bigint(20) unsigned NOT NULL,
  `user` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `pass` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `email` varchar(40) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `tabla_gif`
--
ALTER TABLE `tabla_gif`
  ADD PRIMARY KEY (`gif_id`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `tabla_gif`
--
ALTER TABLE `tabla_gif`
  MODIFY `gif_id` smallint(6) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=59;
--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=17;